import astanait.edu.kz.Book;
import astanait.edu.kz.Cart;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

@WebServlet(name = "/servlet-4")
public class Servlet4  extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nameBook = request.getParameter("name");

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.initializeDatabase();
            statement = connection.createStatement();
            String sql = "SELECT image,name,author,price FROM book WHERE name ='" + nameBook + "'";
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {

                resultSet.getString(1);
                resultSet.getString(2);
                resultSet.getString(3);
                resultSet.getString(4);

                PreparedStatement st = connection.prepareStatement("insert into cart values(?, ?, ?, ?)");


                st.setString(1, resultSet.getString(1));

                st.setString(2, resultSet.getString(2));

                st.setString(3, resultSet.getString(3));

                st.setString(4, resultSet.getString(4));

                st.executeUpdate();
                st.close();
                connection.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                resultSet.close();
                statement.close();
                connection.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
