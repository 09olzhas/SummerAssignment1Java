import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "/servlet-2")
public class Servlet2 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String email = request.getParameter("email");
        String password = request.getParameter("password");
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
             connection = DatabaseConnection.initializeDatabase();

            statement = connection.createStatement();
            String sql = "SELECT email,password FROM person WHERE email ='" + email + "'";
            resultSet = statement.executeQuery(sql);

            while(resultSet.next()) {

                resultSet.getString(1);
                resultSet.getString(2);

                if(resultSet.getString(1).equals(email) && resultSet.getString(2).equals(password)) {

                    Cookie cookie = new Cookie("email", email);
                    cookie.setMaxAge(60 * 10* 10);
                    response.addCookie(cookie);
                    request.getRequestDispatcher("servlet-3").forward(request, response);
                }
                else {
                    request.getRequestDispatcher("errorpage.jsp").forward(request, response);
                }
            }
         }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                  resultSet.close();
                  statement.close();
                  connection.close();
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
