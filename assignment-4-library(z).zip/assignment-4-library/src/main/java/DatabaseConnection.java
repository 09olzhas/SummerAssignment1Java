import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DatabaseConnection {
    protected static Connection initializeDatabase() throws SQLException, ClassNotFoundException
    {
        String connectionStr = "jdbc:postgresql://localhost:5432/postgres";
        Connection connection = DriverManager.getConnection(connectionStr , "postgres"
                ,"qwerty21012815");
        return connection;
    }
}
