package astanait.edu.kz;

public class Cart extends Book {

    public Cart(String image, String name, String author, String price) {
        super(image, name, author, price);
    }

}
