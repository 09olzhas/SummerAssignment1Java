import javax.servlet.http.HttpServlet;

public class Servlet5 extends HttpServlet {

}
