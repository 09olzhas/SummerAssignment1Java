import astanait.edu.kz.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
@WebServlet(name = "/servlet-3")
public class Servlet3 extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.initializeDatabase();

            statement = connection.createStatement();
            String sql = "SELECT*FROM book";
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {

                resultSet.getString(1);
                resultSet.getString(2);
                resultSet.getString(3);
                resultSet.getString(4);
                PrintWriter out = response.getWriter();
/*
                  out.println("<html><body><b>Successfully Inserted"
                                  + "</b></body></html>" +
                        resultSet.getString(1)+ " " +
                        resultSet.getString(2)+ " " +
                        resultSet.getString(3)+ " " +
                       resultSet.getString(4));
*/
                List<Book> books = new ArrayList<Book>();
                books.add(new Book(resultSet.getString(1), resultSet.getString(2),
                        resultSet.getString(3), resultSet.getString(4)));
                request.setAttribute("BookList", books);
            }
            request.getRequestDispatcher("Main.jsp").forward(request, response);

        }

        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                resultSet.close();
                statement.close();
                connection.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
